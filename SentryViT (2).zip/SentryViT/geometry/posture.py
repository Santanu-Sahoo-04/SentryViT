# geometry/posture.py
import numpy as np

class PostureAnalyzer:
    def __init__(self):
        pass

    def cross_ratio_slouch_index(self, A, B, C, D):
        """ 
        (AC * BD) / (AD * BC) 
        Calculates depth/slouch invariant without 3D sensors.
        """
        AC = np.linalg.norm(C - A)
        BD = np.linalg.norm(D - B)
        AD = np.linalg.norm(D - A)
        BC = np.linalg.norm(C - B)
        return (AC * BD) / (AD * BC + 1e-6)